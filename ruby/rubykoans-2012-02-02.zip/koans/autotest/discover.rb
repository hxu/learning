Autotest.add_discovery do
  "rubykoan" if File.exist? 'path_to_enlightenment.rb'
end
